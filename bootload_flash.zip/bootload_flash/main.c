/*
 * 328ADC.c
 *
 * Created: 12/8/2022 8:02:26 PM
 * Author : jason
 */ 

#include <avr/io.h>

uint16_t read_ADC_10bit(uint8_t);
void init_ADC_10bit(void);
void init_IO(void);

int main(void)
{
	init_IO();
	init_ADC_10bit();
    /* Replace with your application code */
    while (1) 
    {
		PORTD = read_ADC_10bit(0);
    }
}

//init_ADC_10bit function
void init_ADC_10bit(void)
{
	ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0);					//activates ADCSRA
	ADMUX = (1<<REFS0);					//sets reference voltage to AREF
	ADCSRB = 0X00;					//sets prescaler to 128
}

//read_ADC_10bit function
uint16_t read_ADC_10bit(uint8_t channel)
{
uint16_t adc_reading = 0;

	ADMUX = (ADMUX & 0XE0) | channel;						//sets channel to user input
	ADCSRA |= (1<<ADSC);					//starts conversion
	while ((ADCSRA & (1<<ADSC)) == 1);			//waits until conversion flag is set

	adc_reading = ADCL;	//stores all bits in 16-bit variable
	adc_reading = adc_reading | (ADCH << 8);
	return adc_reading;							//returns variable
}

void init_IO(void)
{
	DDRC = 0x00;
	PORTC = 0xFF;
	
	DDRD = 0xFF;
	PORTD = 0x00;
}